package dessertCheckOut;

public class Cookie extends DessertItem {
	public Cookie() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cookie(String name,int numberOfCookies) {
		super(name,numberOfCookies);
		// TODO Auto-generated constructor stub
	}


	@Override
	public double itemCost() {
		// TODO Auto-generated method stub
		return 10*super.getNumber()/12;
	}

}
