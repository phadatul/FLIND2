package dessertCheckOut;

public class IceCream extends DessertItem {
	protected final int cost = 30;
	
	public IceCream() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IceCream(String name,int numberOfIceCreams) {
		super(name,numberOfIceCreams);
		// TODO Auto-generated constructor stub
	}
	public int getCost() {
		return cost;
	}
	@Override
	public double itemCost() {
		return this.cost*super.getNumber();
	}

}
