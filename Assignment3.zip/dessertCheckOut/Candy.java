package dessertCheckOut;

public class Candy extends DessertItem {
	private int weight;

	public Candy() {
		super();
		this.weight = 200;
	}

	public Candy(String name, int weight) {
		super(name, 1);
		this.weight = weight;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	@Override
	public double itemCost() {
		return 50 * this.weight / 1000;
	}
}
