package dessertCheckOut;

public class TestCheckOut {
	public static void main(String[] args) {
		CheckOut c = new CheckOut();
		c.getReceipt();
	}
}
