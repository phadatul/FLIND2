package dessertCheckOut;

public class Sundae extends IceCream {
	protected final int costOfToppings = 10;
	private int numberOfToppings;
	public Sundae() {
		super();
		this.numberOfToppings = 1;
		// TODO Auto-generated constructor stub
	}
	public Sundae(String name,int numberOfSundaes,int numberOfToppings) {
		super(name,numberOfSundaes);
		this.numberOfToppings = numberOfToppings;
		// TODO Auto-generated constructor stub
	}
	public int getNumberOfToppings() {
		return numberOfToppings;
	}
	public void setNumberOfToppings(int numberOfToppings) {
		this.numberOfToppings = numberOfToppings;
	}
	public int getCostOfToppings() {
		return costOfToppings;
	}
	@Override
	public double itemCost() {
		// TODO Auto-generated method stub
		return super.itemCost()*this.costOfToppings*this.numberOfToppings;
	}
}
