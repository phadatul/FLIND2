package dessertCheckOut;

public class CheckOut {
	private int numberOfItems = 0;
	private double totalCost = 0;
	Candy d1 = new Candy("Candy",400);
	Cookie d2 = new Cookie("Cookie",4);
	IceCream d3 = new IceCream("IceCream",2);
	Sundae d4 = new Sundae("Sundae",1,2);
	DessertItem items[] = {d1,d2,d3,d4};
	public CheckOut() {
		
	}
	public int numberOfItems() {
		for(DessertItem i : items) {
			this.numberOfItems += i.getNumber();
		}
		return this.numberOfItems;
	}
	public double getTotalCost() {
		for(DessertItem i : items) {
			this.totalCost += i.itemCost();
		}
		return this.totalCost;
	}
	public void getReceipt() {
		this.totalCost = 0;
		this.numberOfItems = 0;
		for(DessertItem i : items) {
			this.numberOfItems += i.getNumber();
			this.totalCost += i.itemCost();
			String s = "Name : "+ i.dessertName() + "     Items : " + i.getNumber() + "   TotalCost : "+i.itemCost();
			System.out.println(s);
			}
		System.out.println("The Final Cost is : "+this.totalCost);
	}

}
