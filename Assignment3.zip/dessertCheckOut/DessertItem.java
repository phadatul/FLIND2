package dessertCheckOut;

public abstract class DessertItem {
	private String name;
	private int number;
	public DessertItem() {
		this.name = "Dessert";
		this.number = 1;
	}
	public DessertItem(String name,int number) {
		this.name = name;
		this.number = number;
	}
	public abstract double itemCost();
	public final String dessertName() {
		return this.name;
	}
	public final int getNumber() {
		return this.number;
	}
}
