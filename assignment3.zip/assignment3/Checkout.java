package assignment3;

public class Checkout {
	static double cashregister=0;
	static void clearCash()
	{
		cashregister=0;
	}
	
	Candy candy;
	Cookie cookie;
	IceCream iceCream;
	Sundae sundae;
	Checkout()
	{
		
	}
	Checkout(int candy,int cookie,int icecream,int sundae,int toppings)
	{
		getInput(candy,cookie,icecream,sundae,toppings);
	}
	public void getInput(int candy,int cookie,int icecream,int sundae,int toppings)
	{
		this.candy=new Candy(candy);
		this.cookie=new Cookie(cookie);
		this.iceCream=new IceCream(icecream);
		this.sundae=new Sundae(sundae,toppings);		
	}	
	
	public double getCost()
	{
		double tmp=0;
		tmp+=candy.getRate();
		tmp+=cookie.getRate();
		tmp+=iceCream.getRate();
		tmp+=sundae.getRate();
		return tmp;
	}
	
	public String reciept()
	{
		String tmp="";
		if(candy.getQuantity()>0)
			tmp+=candy.getName()+" " + candy.getQuantity()+" : "+candy.getRate()+'\n';
		if(iceCream.getQuantity()>0)
			tmp+=iceCream.getName()+" " + iceCream.getQuantity()+" : "+" "+iceCream.getRate()+'\n';
		if(cookie.getQuantity()>0)
			tmp+=cookie.getName()+" "+" " + cookie.getQuantity()+" : "+cookie.getRate()+'\n';
		if(sundae.getQuantity()>0)
			tmp+=sundae.getName()+" "+" " + sundae.getQuantity()+" : "+sundae.getRate()+'\n';
		tmp+=" Total"+getCost();
		
		sundae=null;
		cookie=null;
		candy=null;
		iceCream=null;
		
		return tmp;
	}
	
	
	
}
