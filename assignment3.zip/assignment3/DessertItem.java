package assignment3;

public abstract class  DessertItem {
	public String name;
	final String getName() {
		return name;
	}
	
	
	
	public DessertItem() {
		super();
	}



	public DessertItem(String name) {
		super();
		this.name = name;
	}



	abstract double getRate();
}
