package assignment3;

public class Cookie extends DessertItem{

	final static int costPerDozen=10;
	int quantity;
	
	public Cookie(int quantity) {
		super("Cookie");
		this.quantity = quantity;
	}

	public Cookie() {
		super("Cookie");
	}

	@Override
	double getRate() {
		// TODO Auto-generated method stub
		return (double)quantity*(double)costPerDozen/12;
	}
	

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
