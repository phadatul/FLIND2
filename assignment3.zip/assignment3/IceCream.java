package assignment3;

public class IceCream extends DessertItem {
	int quantity;
	static int cost=10;
	
	public IceCream(int quantity) {
		super("Ice Cream");
		this.quantity = quantity;
	}
	
	public IceCream(String name,int quan)
	{
		super(name);
		this.quantity=quan;
	}
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	double getRate() {
			return quantity*cost;
	}

}
