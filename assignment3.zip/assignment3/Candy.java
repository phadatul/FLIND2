package assignment3;

public class Candy  extends DessertItem{

	static int costperKG=50;
	int quantity;
	public Candy(int grams) {
		super("Candy");
		quantity=grams;
		// TODO Auto-generated constructor stub
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Candy() {
		super("Candy");
	}

	@Override
	double getRate() {
		// TODO Auto-generated method stub
		return quantity*costperKG/1000;
	}

}
