package assignment3;

public class TestCheckout {
	public static void main(String[] args)
	{
		Checkout check=new Checkout();
		check.getInput(200, 4, 10, 2, 2);
		System.out.print(check.reciept());
	}
}
