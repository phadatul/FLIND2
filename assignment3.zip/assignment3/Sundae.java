package assignment3;

public class Sundae extends IceCream{

	static int costOfToppings=2;
	int toppintQuantity;
	public Sundae(int quantity,int toppintQuantity) {
		super("Sundae",quantity);
		if(quantity==0)
			{
			this.toppintQuantity=0;	
			}
		else
			this.toppintQuantity=toppintQuantity;	
	}
	
	@Override
	double getRate() {
			return super.getRate()+toppintQuantity*costOfToppings;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
